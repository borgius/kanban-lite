# n8n-nodes-kanban-lite

First-party [n8n](https://n8n.io) node package for [Kanban Lite](https://github.com/borgius/kanban-lite).

Provides two nodes:

| Node | Type | Description |
|------|------|-------------|
| **Kanban Lite** | App node | Full action surface – boards, cards, comments, attachments, columns, labels, settings, webhooks, workspace |
| **Kanban Lite Trigger** | Trigger node | Event-driven triggers for card/board/column/comment/attachment/label lifecycle events |

Both nodes support two transport modes:

| Mode | Credential | When to use |
|------|-----------|-------------|
| **Remote API** | `Kanban Lite API` | n8n connects to a running Kanban Lite standalone server over HTTP |
| **Local SDK** | `Kanban Lite SDK (Local)` | n8n runs on the same machine as the workspace and accesses it directly via the SDK |

> **Transport availability note** – Local SDK mode can observe _before-_ and _after-_ events. Remote API mode receives committed after-events only (webhook delivery from the standalone server).

---

## Install

### Via n8n community nodes UI

1. Open n8n → **Settings → Community Nodes**
2. Enter `n8n-nodes-kanban-lite` and install

### Manual / private node

```bash
# inside your n8n custom data directory
cd ~/.n8n
npm install n8n-nodes-kanban-lite
```

Then restart n8n.

---

## Configuration

### Remote API credential

Create a **Kanban Lite API** credential:

| Field | Description |
|-------|-------------|
| Base URL | URL of the Kanban Lite standalone server (e.g. `http://localhost:3000`) |
| Auth Mode | `None`, `Bearer Token`, or `API Key Header` – must match your server auth plugin |
| Token / API Key | Secret value (used when Auth Mode is not `None`) |
| API Key Header Name | Header name to use when Auth Mode is `API Key Header` (default: `X-Api-Key`) |

### Local SDK credential

Create a **Kanban Lite SDK (Local)** credential:

| Field | Description |
|-------|-------------|
| Workspace Root | Absolute path to the directory containing `.kanban.json` |
| Board Directory | Optional: absolute path to the board directory (defaults to workspace root) |

---

## Private / local development

To use this package from source in the monorepo during development:

```bash
# Build the package
cd packages/n8n-nodes-kanban-lite
pnpm run build

# Symlink into your n8n custom nodes directory
ln -s "$(pwd)" ~/.n8n/custom/n8n-nodes-kanban-lite
```

Then restart n8n and the nodes will be available.

---

## Local SDK transport requirements

When using **Local SDK** mode:

- n8n must run on the same machine as the Kanban Lite workspace
- The workspace root path must be accessible to the n8n process
- The Kanban Lite standalone server does **not** need to be running

---

## Supported events (Trigger node)

| Event | SDK (before) | SDK (after) | API (after) |
|-------|:---:|:---:|:---:|
| `card.created` | ✗ | ✓ | ✓ |
| `card.updated` | ✗ | ✓ | ✓ |
| `card.deleted` | ✗ | ✓ | ✓ |
| `card.moved` | ✗ | ✓ | ✓ |
| `board.created` | ✗ | ✓ | ✓ |
| `board.updated` | ✗ | ✓ | ✓ |
| `board.deleted` | ✗ | ✓ | ✓ |
| `column.created` | ✗ | ✓ | ✓ |
| `column.updated` | ✗ | ✓ | ✓ |
| `column.deleted` | ✗ | ✓ | ✓ |
| `comment.created` | ✗ | ✓ | ✓ |
| `comment.deleted` | ✗ | ✓ | ✓ |
| `attachment.added` | ✗ | ✓ | ✓ |
| `attachment.removed` | ✗ | ✓ | ✓ |
| `label.created` | ✗ | ✓ | ✓ |
| `label.updated` | ✗ | ✓ | ✓ |
| `label.deleted` | ✗ | ✓ | ✓ |

_Before-event availability is expanded when the event catalog (T1) confirms SDK-before hooks for specific operations._

---

## Links

- [Kanban Lite docs](https://github.com/borgius/kanban-lite)
- [API reference](https://github.com/borgius/kanban-lite/blob/main/docs/api.md)
- [Auth & security](https://github.com/borgius/kanban-lite/blob/main/docs/auth.md)
